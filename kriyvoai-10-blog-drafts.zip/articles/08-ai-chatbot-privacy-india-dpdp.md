---
title: "AI Chatbot Privacy Checklist for Indian Businesses: What to Review Before Launch"
slug: "ai-chatbot-privacy-india-dpdp"
category: "Engineering"
seo_title: "AI Chatbot Data Privacy India: Pre-Launch Checklist"
meta_description: "A practical India-focused checklist for chatbot data collection, notices, AI vendors, security, retention and breach readiness before launch."
primary_keyword: "AI chatbot data privacy India"
status: "unpublished draft"
---

# AI Chatbot Privacy Checklist for Indian Businesses: What to Review Before Launch
A website chatbot is another place where customer data enters your business. A visitor may share a phone number, order details or health information in a free-text box, even if your team only planned to answer basic questions. Before launch, decide what the bot should collect, where that information goes and who is responsible when something goes wrong.

This checklist is an operational starting point, not legal advice. It focuses on privacy decisions specific to a customer-facing AI chatbot, rather than chatbot setup or general website security.

## 1. Map what the chatbot actually collects

Walk through a real conversation and list every data field and free-text input. Include details captured automatically, such as IP address, device identifiers or chat timestamps, where applicable. For each item, write down why it is needed, which team uses it, and where it is stored.

Keep the bot’s questions narrow. If it can answer a product query without a customer’s full address or account number, do not ask for those details. Tell visitors not to share passwords, card details or sensitive personal information in an open chat. If a case needs identity verification, move it to a suitable secure channel rather than asking the bot to collect more than it needs.

## 2. Make the notice match the conversation

Place a short, readable notice beside the chat launcher or at the start of a conversation. Explain what information may be collected, why it is used, whether an AI service provider processes the conversation, and how a visitor can reach a person or contact your business about their data. Avoid a vague line such as “we use data to improve services” if the chat is also used to qualify leads or create support tickets.

The DPDP Act sets out requirements for lawful processing, notice and consent, including that consent be specific, informed and affirmative where consent is the basis. It also provides for certain legitimate uses, so do not assume every conversation has the same legal basis. The Act’s main processing provisions are scheduled to commence 18 months after the 13 November 2025 notification—13 May 2027. As of 25 October 2026, treat this as preparation and confirm the commencement position and any later changes before relying on a compliance interpretation. [1] [2]

## 3. Trace every company that touches a chat

Draw the data route from the website widget to your hosting provider, AI model, automation tool, CRM, email or WhatsApp inbox, and analytics or support logs. Ask each vendor what it receives, how long it keeps prompts and outputs, whether it uses them to improve or train services, which subprocessors are involved, and how deletion and incident notification work. Check the actual plan and settings you will use; a vendor’s general privacy page may not describe your configuration.

Put responsibilities in writing. The DPDP Act recognises data processors handling personal data on a business’s behalf and requires a valid contract for engaging a processor; it also places obligations on the Data Fiduciary. Ask for clear terms covering permitted use, access, safeguards, retention, deletion, subcontracting and breach escalation. [1]

## 4. Set retention, access and a human route

Decide how long transcripts are useful. A lead may need a short follow-up window; a support conversation may need to stay with a ticket for a defined period. Avoid keeping all chats indefinitely “just in case”. Make sure deletion reaches connected systems, exports and vendor dashboards, and understand what happens to backups and logs.

Give staff access only when their role requires it. Use individual accounts, strong authentication and periodic access reviews. Redact or mask data before it is sent to an AI model where feasible, and do not place API keys, passwords or internal-only instructions in the chat context. Test common failure cases: a visitor asks for another customer’s order, pastes a secret, or requests deletion. The bot should not reveal another person’s information, and it should provide a clear hand-off when it cannot safely resolve the request.

The DPDP Rules notified in 2025 describe safeguards such as encryption or masking, access controls, logs, backups and contractual security provisions for processors. Their main operational provisions are also phased, with Rules 3 and 5–16, 22 and 23 scheduled after 18 months from publication. Use these as design requirements to prepare for, and verify the applicable effective date before treating them as live duties. [2] [3]

## 5. Rehearse an incident before launch

Name the person who can pause the bot, revoke a vendor credential, contact providers and preserve relevant logs. Agree in advance how quickly a chatbot vendor must notify you of a suspected exposure. CERT-In’s directions separately require specified cyber incidents to be reported within six hours of noticing them or being informed; its list includes data breaches, data leaks and incidents affecting AI/ML systems. Keep this distinct from the DPDP Rules’ personal-data breach notification process, which is scheduled to take effect with the phased rules. [4] [3]

A useful launch test is simple: can your team identify what data was exposed, which provider held it, whom to contact, and what action to take without searching through scattered accounts?

## FAQ: Does a chatbot need to collect a visitor’s phone number?

Only if it is needed for a stated purpose, such as a requested callback or order follow-up. Offer a way to browse answers without sharing contact details, and explain what happens after a visitor provides them.

Before publishing, run the checklist with whoever owns your website, customer support and vendor accounts. If you are planning a website chatbot, [Kriyvo AI’s chatbot service](https://kriyvoai.online/services/ai-chatbot-for-website) is one option to discuss alongside your privacy and handover requirements.

## References

[1]: https://www.meity.gov.in/static/uploads/2024/06/2bf1f0e9f04e6fb4f8fef35e82c42aa5.pdf "The Digital Personal Data Protection Act, 2023"
[2]: https://www.meity.gov.in/static/uploads/2025/11/c56ceae6c383460ca69577428d36828b.pdf "MeitY notification specifying commencement dates under the DPDP Act"
[3]: https://www.meity.gov.in/static/uploads/2025/11/53450e6e5dc0bfa85ebd78686cadad39.pdf "Digital Personal Data Protection Rules, 2025"
[4]: https://www.cert-in.org.in/PDF/CERT-In_Directions_70B_28.04.2022.pdf "CERT-In Directions under Section 70B, dated 28 April 2022"
